from ai_pkg.search import *

city_map = Graph(dict(
        NewYork=dict(Chicago=1000, Toronto=800, Denver=1900),
        Chicago=dict(Denver=1000),
        Denver=dict(LosAngeles=1000, Houston=1500, Urbana=1000),
        Houston=dict(LosAngeles=1500),
        Toronto=dict(LosAngeles=1800, Chicago=500, Calgary=1500)),
directed=True)

class CityProblem(Problem):
    def __init__(self, initial, goal, graph):
        Problem.__init__(self, initial, goal)
        self.graph = graph
    def actions(self, A):
        return list(self.graph.get(A).keys())
    def result(self, state, action):
        return action
    def path_cost(self, cost, A, action, B):
        return cost + (self.graph.get(A, B) or infinity)

def breadth_first_search(problem):
    global track_path
    frontier = deque([Node(problem.initial)])
    explored = set()
    track_path = [problem.initial]
    while frontier:
        node = frontier.popleft()
        if problem.goal_test(node.state):
            return node
        explored.add(node.state)
        expanded = node.expand(problem)
        for child in expanded:
            track_path.append(child.state)
            if child.state not in explored and child not in frontier:
                if problem.goal_test(child.state):
                    return child
                frontier.append(child)
    return None
