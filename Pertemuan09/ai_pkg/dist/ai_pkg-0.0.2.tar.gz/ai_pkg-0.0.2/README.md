# Simple AI Package
This is a simple example package that includes custom ai_pkg functions that I've done in Praktikum Kecerdasan Buatan
## Hope it useful :)